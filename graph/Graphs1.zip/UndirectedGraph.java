public class UndirectedGraph extends GraphAPI {

    public UndirectedGraph(int V) {
        super(V);
    }

    @Override
    public void addEdge(int v, int w) {
        adj[v].enqueue(w);
        adj[w].enqueue(v);
    }
}
