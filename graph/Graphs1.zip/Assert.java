public class Assert {
	public static void assertEquals(int expected, int actual) throws Exception {
		if (expected != actual)
			throw new Exception("Expected " + expected + " but found " + actual);

	}

	public static void assertTrue(boolean b) throws Exception {
		if (!b)
			throw new Exception("Expected true but found false");
	}

	public static void assertFalse(boolean b) throws Exception {
		if (b)
			throw new Exception("Expected false but found true");
	}

	public static void assertArrayEquals(int[] expected, int[] actual) throws Exception {
		if (expected.length != actual.length)
			throw new Exception("Both arrays not equal in size");

		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i], actual[i]);
		}
	}
}
