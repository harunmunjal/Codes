/**
 *
 * @author Ritesh
 */
public class CC {
	public int[] cc;
	public boolean[] marked;
	private int count;
	private UndirectedGraph g;

	public CC(UndirectedGraph g) {
		this.g = g;
		cc = new int[g.V()];
		marked = new boolean[g.V()];
		for (int s = 0; s < g.V(); s++) {
			if (!marked[s]) {
				dfs(s);
				count++;
			}
		}
	}

	private void dfs(int s) {
		marked[s] = true;
		cc[s] = count;
		for (int v : g.adj(s)) {
			if (!marked[v]) {
				dfs(v);
			}
		}
	}

	public int[] getCc() {
		return cc;
	}
}
