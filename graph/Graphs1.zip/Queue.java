import java.util.Arrays;
import java.util.Iterator;
/**
 *
 * @author Ritesh_Ranjan
 * @param <E>
 */
public class Queue<E> implements Iterable<E> {

	E[] a;
	int head, tail, total;

	@SuppressWarnings("unchecked")
	public Queue(int i) {
		a = (E[]) new Object[10];
	}

	@SuppressWarnings("unchecked")
	public Queue() {
		a = (E[]) new Object[10];
	}

	public void enqueue(E e) {
		if (isFull()) {
			resize();// throw new IllegalStateException("OverFlow");
		}
		a[tail++] = e;
		if (tail == a.length) {
			tail = 0;
		}
		total++;
	}

	public E dequeue() {
		if (isEmpty()) {
			throw new IllegalStateException("UnderFlow");
		}
		total--;
		E e = a[head++];
		if (head == a.length) {
			head = 0;
		}
		return e;
	}

	public boolean isEmpty() {
		return total == 0;
	}

	@SuppressWarnings("unchecked")
	private void resize() {
		int t = total;
		E[] temp = (E[]) new Object[a.length + a.length * 2];
		for (int i = 0; i < t; i++) {
			temp[i] = dequeue();
		}
		a = Arrays.copyOf(temp, temp.length);
		tail = t;
		head = 0;
		total = t;
	}

	private boolean isFull() {
		return total >= a.length;
	}

	@Override
	public Iterator<E> iterator() {
		return new CustomIterator();
	}

	private class CustomIterator implements Iterator<E> {
		int current = head;
		int currentTotal = total;

		@Override
		public boolean hasNext() {
			return currentTotal != 0;
		}

		@Override
		public E next() {
			currentTotal--;
			return a[current++];
		}

		@Override
		public void remove() {
		}
	}
}
