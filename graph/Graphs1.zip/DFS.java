public class DFS {
	public boolean[] marked;
	public int[] edgeTo;
	private UndirectedGraph g;

	public DFS(UndirectedGraph g, int s) {
		this.g = g;
		marked = new boolean[g.V()];
		dfs(s);
	}

	private void dfs(int s) {
		marked[s] = true;
		for (int x : g.adj(s)) {
			if (marked[x] == false) {
				dfs(x);
			}
		}
	}
}
