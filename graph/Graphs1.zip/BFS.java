public class BFS {
	public boolean[] marked;
	public int[] edgeTo;
	private UndirectedGraph g;

	public BFS(UndirectedGraph g, int s) {
		this.g = g;
		marked = new boolean[g.V()];
		edgeTo = new int[g.V()];
		bfs(s);
	}

	private void bfs(int s) {
		Queue<Integer> q = new Queue<>();
		q.enqueue(s);
		while (!q.isEmpty()) {
			int x = q.dequeue();
			marked[x] = true;
			for (int y : g.adj(x)) {
				if (marked[y] == false) {
					marked[y] = true;
					edgeTo[y] = x;
					q.enqueue(y);
				}
			}
		}
	}
}
